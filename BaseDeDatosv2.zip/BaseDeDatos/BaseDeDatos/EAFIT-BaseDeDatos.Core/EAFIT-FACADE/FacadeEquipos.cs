﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EAFIT_BaseDeDatos.Core.EAFIT_MANAGER;

namespace EAFIT_BaseDeDatos.Core.EAFIT_FACADE
{
    
    
        public class FacadeEquipos
        {

            public bool InsertarEquipo(Dictionary<string, string> ValuesEquipo)
            {
                EAFIT_MANAGER.ManagerEquipos InsertEquipo = new EAFIT_MANAGER.ManagerEquipos();
                return InsertEquipo.InsertarEquipos(ValuesEquipo);

            }
            public bool ActualizarEquipos(Dictionary<string, string> ValuesEquipo)
            {
                EAFIT_MANAGER.ManagerEquipos InsertEquipos = new EAFIT_MANAGER.ManagerEquipos();
                return InsertEquipos.ActualizarEquipos(ValuesEquipo);

            }
            
            public Dictionary<string, string> ValidarEquipo(string EquipoSearch)
            {

                ManagerEquipos ValidateEquipos = new ManagerEquipos();
                return ValidateEquipos.ValidarEquipo(EquipoSearch);
            }
        }
    }

