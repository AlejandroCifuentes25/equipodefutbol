﻿using EAFIT_BaseDeDatos.Core.EAFIT_BROKER;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAFIT_BaseDeDatos.Core.EAFIT_MANAGER
{
    class ManagerLocalidades
    {
        internal bool InsertarLocalidad(Dictionary<string, string> ValuesLocalidad)
        {
            BrokerLocalidades insertLocalidad = new BrokerLocalidades();
            return insertLocalidad.InsertarLocalidad(ValuesLocalidad);
        }

        internal bool ActualizarLocalidad(Dictionary<string, string> ValuesLocalidad)
        {
            BrokerLocalidades updateLocalidad = new BrokerLocalidades();
            return updateLocalidad.ActualizarLocalidad(ValuesLocalidad);
        }

        internal Dictionary<string, string> ValidarLocalidad(string NombreLocalidad)
        {
            BrokerLocalidades validateLocalidad = new BrokerLocalidades();
            return validateLocalidad.ValidarLocalidad(NombreLocalidad);
        }
    }
}
