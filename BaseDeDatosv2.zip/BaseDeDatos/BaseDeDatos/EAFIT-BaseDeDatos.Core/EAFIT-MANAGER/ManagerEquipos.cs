﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EAFIT_BaseDeDatos.Core.EAFIT_BROKER;

namespace EAFIT_BaseDeDatos.Core.EAFIT_MANAGER
{
     class ManagerEquipos   
    {
        internal bool InsertarEquipos(Dictionary<string, string> ValuesEquipo)
        {
            BrokerEquipos InsertEquipos = new BrokerEquipos();
         

            return InsertEquipos.InsertarEquipo(ValuesEquipo);

        }
        internal bool ActualizarEquipos(Dictionary<string, string> ValuesEquipo)
        {
            BrokerEquipos UpdateEquipo = new BrokerEquipos();
         

            return UpdateEquipo.ActualizarEquipo(ValuesEquipo);

        }
        
        internal Dictionary<string, string> ValidarEquipo(string EquipoSearch)
        {

            BrokerEquipos ValidateEquipo = new BrokerEquipos();
            return ValidateEquipo.ValidarEquipo(EquipoSearch);
        }
        


    }
}

