﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EAFIT_BaseDeDatos.Core.EAFIT_BROKER
{
    internal class BrokerEquipos
    {
        MySqlConnection Connection;
        BrokerConnection InsConnection = new BrokerConnection();
        internal bool InsertarEquipo(Dictionary<string, string> ValuesEquipo)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacLogeo = new MySqlCommand();
            transacLogeo.CommandText = string.Format("CALL  InsertarEquipo('{0}','{1}','{2}');", ValuesEquipo.GetValueOrDefault("Nombre"),
                ValuesEquipo.GetValueOrDefault("Ciudad"), ValuesEquipo.GetValueOrDefault("Tipo"));
            transacLogeo.Connection = Connection;
            int ResultLogin = transacLogeo.ExecuteNonQuery();
            InsConnection.CloseConnection(Connection);
            if (ResultLogin > 0)
                return true;
            else
                return false;
        }

     
        internal Dictionary<string, string> ValidarEquipo(string EquipoSearch)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacLogeo = new MySqlCommand();
            transacLogeo.CommandText = string.Format("select id_equipo, nombre, Ciudad, tipo from equipos where nombre = '{0}'", EquipoSearch);
            transacLogeo.Connection = Connection;
            Dictionary<string, string> ReturnEquipo = new Dictionary<string, string>();
            MySqlDataReader Result = transacLogeo.ExecuteReader();
            while (Result.Read())
            {
                ReturnEquipo.Add("id_estadio", Result[0].ToString());
                ReturnEquipo.Add("Nombre", Result[1].ToString());
                ReturnEquipo.Add("ciudad", Result[2].ToString());
                ReturnEquipo.Add("tipo", Result[3].ToString());
                
            }
            InsConnection.CloseConnection(Connection);
            return ReturnEquipo;
        }
        internal bool ActualizarEquipo(Dictionary<string, string> ValuesEquipo)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacUpdate = new MySqlCommand();

            transacUpdate.CommandText = string.Format("CALL  ActualizarEquipo( {0} , {1} , {2});",
                    string.IsNullOrEmpty(ValuesEquipo.GetValueOrDefault("nombre")) ? null : string.Concat("'", ValuesEquipo.GetValueOrDefault("nombre"), "'"),
                    string.IsNullOrEmpty(ValuesEquipo.GetValueOrDefault("ciudad")) ? null : string.Concat("'", ValuesEquipo.GetValueOrDefault("ciudad"), "'"),
                    string.IsNullOrEmpty(ValuesEquipo.GetValueOrDefault("tipo")) ? null : string.Concat("'", ValuesEquipo.GetValueOrDefault("tipo"), "'"));
                    
            transacUpdate.Connection = Connection;
            int ResultLogin = transacUpdate.ExecuteNonQuery();
            InsConnection.CloseConnection(Connection);
            if (ResultLogin > 0)
                return true;
            else
                return false;
        }

    }

}
