﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EAFIT_BaseDeDatos.Core.EAFIT_FACADE;

namespace EAFIT_BaseDeDatos.UI
{
    public partial class Equipos : Form
    {
        public Equipos(Form instanciaPpal)
        {
            InitializeComponent();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {

        }

        private void TxtApellidos_TextChanged(object sender, EventArgs e)
        {

        }

        private void Equipos_Load(object sender, EventArgs e)
        {

        }

        private void BtnConsultarEquipo_Click(object sender, EventArgs e)
        {
            BtnIngresar.Enabled = false;
            BtnUpdate.Enabled = BtnDelete.Enabled = true;

            FacadeEquipos instSearch = new FacadeEquipos();
            Dictionary<string, string> result = instSearch.ValidarEquipo(TxtNameEquipo.Text);

            if (result != null && result.Count > 0)
            {
                TxtNameEquipo.Text = result.GetValueOrDefault("nombre");
                TxtCiudadEquipo.Text = result.GetValueOrDefault("ubicacion");
                TxtTipoEquipo.Text = result.GetValueOrDefault("capacidad_total");
            }
        }

        private void TxtTipoEquipo_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNameEquipo_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void BtnIngresar_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
