﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EAFIT_BaseDeDatos.Core.EAFIT_FACADE;

namespace EAFIT_BaseDeDatos.UI
{
    public partial class Estadios : Form
    {
        public Estadios(Form instanciaPpal)
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            LLConfiguracion = new LinkLabel();
            button1 = new Button();
            BtnConsultar = new Button();
            BtnNewUser = new Button();
            BtnDelete = new Button();
            BtnUpdate = new Button();
            TxtNameEst = new TextBox();
            NombreEst = new Label();
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            LblTitulo = new Label();
            TxtCapacidad = new TextBox();
            TxtUbicacionEst = new TextBox();
            LblPassword = new Label();
            LblUsuario = new Label();
            BtnIngresar = new Button();
            BtnSalir = new Button();
            SuspendLayout();
            // 
            // LLConfiguracion
            // 
            LLConfiguracion.AutoSize = true;
            LLConfiguracion.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LLConfiguracion.LinkBehavior = LinkBehavior.NeverUnderline;
            LLConfiguracion.LinkColor = Color.Black;
            LLConfiguracion.Location = new Point(569, 346);
            LLConfiguracion.Margin = new Padding(2, 0, 2, 0);
            LLConfiguracion.Name = "LLConfiguracion";
            LLConfiguracion.Size = new Size(0, 24);
            LLConfiguracion.TabIndex = 22;
            // 
            // button1
            // 
            button1.BackColor = Color.Navy;
            button1.Font = new Font("Candara", 9F);
            button1.ForeColor = Color.White;
            button1.Location = new Point(879, 92);
            button1.Margin = new Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new Size(135, 44);
            button1.TabIndex = 57;
            button1.Text = " Menú";
            button1.UseVisualStyleBackColor = false;
            // 
            // BtnConsultar
            // 
            BtnConsultar.BackColor = Color.Navy;
            BtnConsultar.Font = new Font("Candara", 9F);
            BtnConsultar.ForeColor = Color.White;
            BtnConsultar.Location = new Point(634, 220);
            BtnConsultar.Margin = new Padding(4, 5, 4, 5);
            BtnConsultar.Name = "BtnConsultar";
            BtnConsultar.Size = new Size(135, 44);
            BtnConsultar.TabIndex = 44;
            BtnConsultar.Text = "Consultar!!";
            BtnConsultar.UseVisualStyleBackColor = false;
            BtnConsultar.Click += BtnConsultar_Click;
            // 
            // BtnNewUser
            // 
            BtnNewUser.BackColor = Color.Navy;
            BtnNewUser.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnNewUser.ForeColor = Color.White;
            BtnNewUser.Location = new Point(59, 116);
            BtnNewUser.Margin = new Padding(4, 5, 4, 5);
            BtnNewUser.Name = "BtnNewUser";
            BtnNewUser.Size = new Size(162, 58);
            BtnNewUser.TabIndex = 34;
            BtnNewUser.Text = "Nuevo!!";
            BtnNewUser.UseVisualStyleBackColor = false;
            // 
            // BtnDelete
            // 
            BtnDelete.BackColor = Color.Navy;
            BtnDelete.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnDelete.ForeColor = Color.White;
            BtnDelete.Location = new Point(1043, 506);
            BtnDelete.Margin = new Padding(4, 5, 4, 5);
            BtnDelete.Name = "BtnDelete";
            BtnDelete.Size = new Size(162, 58);
            BtnDelete.TabIndex = 46;
            BtnDelete.Text = "Inactivar!!";
            BtnDelete.UseVisualStyleBackColor = false;
            // 
            // BtnUpdate
            // 
            BtnUpdate.BackColor = Color.Navy;
            BtnUpdate.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnUpdate.ForeColor = Color.White;
            BtnUpdate.Location = new Point(843, 505);
            BtnUpdate.Margin = new Padding(4, 5, 4, 5);
            BtnUpdate.Name = "BtnUpdate";
            BtnUpdate.Size = new Size(162, 58);
            BtnUpdate.TabIndex = 45;
            BtnUpdate.Text = "Actualizar!!";
            BtnUpdate.UseVisualStyleBackColor = false;
            // 
            // TxtNameEst
            // 
            TxtNameEst.Font = new Font("Candara Light", 10F);
            TxtNameEst.Location = new Point(321, 226);
            TxtNameEst.Margin = new Padding(4, 5, 4, 5);
            TxtNameEst.Name = "TxtNameEst";
            TxtNameEst.Size = new Size(265, 28);
            TxtNameEst.TabIndex = 35;
            TxtNameEst.TextChanged += TxtNameEst_TextChanged;
            // 
            // NombreEst
            // 
            NombreEst.AutoSize = true;
            NombreEst.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            NombreEst.ForeColor = Color.Navy;
            NombreEst.Location = new Point(59, 229);
            NombreEst.Margin = new Padding(4, 0, 4, 0);
            NombreEst.Name = "NombreEst";
            NombreEst.Size = new Size(83, 24);
            NombreEst.TabIndex = 54;
            NombreEst.Text = "Nombre:";
            NombreEst.Click += NombreEst_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(59, 604);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(0, 24);
            label3.TabIndex = 53;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(59, 521);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(0, 24);
            label1.TabIndex = 52;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(59, 441);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(0, 24);
            label2.TabIndex = 51;
            // 
            // LblTitulo
            // 
            LblTitulo.AutoSize = true;
            LblTitulo.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblTitulo.ForeColor = Color.Navy;
            LblTitulo.Location = new Point(447, 39);
            LblTitulo.Margin = new Padding(4, 0, 4, 0);
            LblTitulo.Name = "LblTitulo";
            LblTitulo.Size = new Size(233, 24);
            LblTitulo.TabIndex = 50;
            LblTitulo.Text = "Administración de estadios";
            // 
            // TxtCapacidad
            // 
            TxtCapacidad.Font = new Font("Candara Light", 10F);
            TxtCapacidad.Location = new Point(321, 365);
            TxtCapacidad.Margin = new Padding(4, 5, 4, 5);
            TxtCapacidad.Name = "TxtCapacidad";
            TxtCapacidad.Size = new Size(265, 28);
            TxtCapacidad.TabIndex = 37;
            // 
            // TxtUbicacionEst
            // 
            TxtUbicacionEst.Font = new Font("Candara Light", 10F);
            TxtUbicacionEst.Location = new Point(321, 296);
            TxtUbicacionEst.Margin = new Padding(4, 5, 4, 5);
            TxtUbicacionEst.Name = "TxtUbicacionEst";
            TxtUbicacionEst.Size = new Size(265, 28);
            TxtUbicacionEst.TabIndex = 36;
            TxtUbicacionEst.TextChanged += TxtUsuario_TextChanged;
            // 
            // LblPassword
            // 
            LblPassword.AutoSize = true;
            LblPassword.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblPassword.ForeColor = Color.Navy;
            LblPassword.Location = new Point(59, 373);
            LblPassword.Margin = new Padding(4, 0, 4, 0);
            LblPassword.Name = "LblPassword";
            LblPassword.Size = new Size(146, 24);
            LblPassword.TabIndex = 49;
            LblPassword.Text = "Capacidad total:";
            // 
            // LblUsuario
            // 
            LblUsuario.AutoSize = true;
            LblUsuario.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblUsuario.ForeColor = Color.Navy;
            LblUsuario.Location = new Point(59, 298);
            LblUsuario.Margin = new Padding(4, 0, 4, 0);
            LblUsuario.Name = "LblUsuario";
            LblUsuario.Size = new Size(98, 24);
            LblUsuario.TabIndex = 48;
            LblUsuario.Text = "Ubicación:";
            // 
            // BtnIngresar
            // 
            BtnIngresar.BackColor = Color.Navy;
            BtnIngresar.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnIngresar.ForeColor = Color.White;
            BtnIngresar.Location = new Point(646, 505);
            BtnIngresar.Margin = new Padding(4, 5, 4, 5);
            BtnIngresar.Name = "BtnIngresar";
            BtnIngresar.Size = new Size(162, 58);
            BtnIngresar.TabIndex = 43;
            BtnIngresar.Text = "Guardar!!";
            BtnIngresar.UseVisualStyleBackColor = false;
            // 
            // BtnSalir
            // 
            BtnSalir.BackColor = Color.Navy;
            BtnSalir.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnSalir.ForeColor = Color.White;
            BtnSalir.Location = new Point(1043, 619);
            BtnSalir.Margin = new Padding(4, 5, 4, 5);
            BtnSalir.Name = "BtnSalir";
            BtnSalir.Size = new Size(162, 58);
            BtnSalir.TabIndex = 47;
            BtnSalir.Text = "Salir";
            BtnSalir.UseVisualStyleBackColor = false;
            // 
            // Estadios
            // 
            ClientSize = new Size(1265, 717);
            Controls.Add(button1);
            Controls.Add(BtnConsultar);
            Controls.Add(BtnNewUser);
            Controls.Add(BtnDelete);
            Controls.Add(BtnUpdate);
            Controls.Add(TxtNameEst);
            Controls.Add(NombreEst);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(LblTitulo);
            Controls.Add(TxtCapacidad);
            Controls.Add(TxtUbicacionEst);
            Controls.Add(LblPassword);
            Controls.Add(LblUsuario);
            Controls.Add(BtnIngresar);
            Controls.Add(BtnSalir);
            Controls.Add(LLConfiguracion);
            Name = "Estadios";
            Text = "Estadios";
            ResumeLayout(false);
            PerformLayout();

        }
        private LinkLabel LLConfiguracion;
        private Button button1;
        private Button BtnConsultar;
        private Button BtnNewUser;
        private Button BtnDelete;
        private Button BtnUpdate;
        private TextBox TxtNameEst;
        private Label NombreEst;
        private Label label3;
        private Label label1;
        private Label label2;
        private Label LblTitulo;
        private TextBox TxtCapacidad;
        private TextBox TxtUbicacionEst;
        private Label LblPassword;
        private Label LblUsuario;
        private Button BtnIngresar;
        private Button BtnSalir;

        private void CBState_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TxtUsuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void NombreEst_Click(object sender, EventArgs e)
        {

        }

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            BtnIngresar.Enabled = false;
            BtnUpdate.Enabled = BtnDelete.Enabled = true;

            FacadeEstadios instSearch = new FacadeEstadios();
            Dictionary<string, string> result = instSearch.ValidarEstadio(TxtNameEst.Text);

            if (result != null && result.Count > 0)
            {
                TxtNameEst.Text = result.GetValueOrDefault("nombre");
                TxtUbicacionEst.Text = result.GetValueOrDefault("ubicacion");
                TxtCapacidad.Text = result.GetValueOrDefault("capacidad_total");
            }
        }

        private void TxtNameEst_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
