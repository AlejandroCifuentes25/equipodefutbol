﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EAFIT_BaseDeDatos.Core.EAFIT_FACADE;

namespace EAFIT_BaseDeDatos.UI
{
    public partial class Localidades : Form
    {
        public Localidades(Form instanciaPpal)
        {
            InitializeComponent();
        }

        private void TxtIdEst_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            BtnIngresar.Enabled = false;
            BtnUpdate.Enabled = BtnDelete.Enabled = true;

            FacadeLocalidades instSearch = new FacadeLocalidades();
            Dictionary<string, string> result = instSearch.ValidarLocalidad(TxtIdEst.Text);

            if (result != null && result.Count > 0)
            {
                TxtIdEst.Text = result.GetValueOrDefault("id_estadio");
                TxtNameLoc.Text = result.GetValueOrDefault("nombre_localidad");
                TxtAforo.Text = result.GetValueOrDefault("aforo");
            }
        }

        private void LblTitulo_Click(object sender, EventArgs e)
        {

        }
    }
}
