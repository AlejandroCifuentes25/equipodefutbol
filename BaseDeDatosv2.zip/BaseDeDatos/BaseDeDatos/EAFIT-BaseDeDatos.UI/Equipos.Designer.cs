﻿namespace EAFIT_BaseDeDatos.UI
{
    partial class Equipos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            BtnConsultar = new Button();
            BtnNewUser = new Button();
            TxtTipoEquipo = new TextBox();
            BtnDelete = new Button();
            BtnUpdate = new Button();
            TxtNameEquipo = new TextBox();
            label4 = new Label();
            label2 = new Label();
            TxtCiudadEquipo = new TextBox();
            LblPassword = new Label();
            LblUsuario = new Label();
            BtnIngresar = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = Color.Navy;
            button2.Font = new Font("Candara", 9F);
            button2.ForeColor = Color.White;
            button2.Location = new Point(876, 102);
            button2.Margin = new Padding(4, 5, 4, 5);
            button2.Name = "button2";
            button2.Size = new Size(135, 44);
            button2.TabIndex = 74;
            button2.Text = " menú";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // BtnConsultar
            // 
            BtnConsultar.BackColor = Color.Navy;
            BtnConsultar.Font = new Font("Candara", 9F);
            BtnConsultar.ForeColor = Color.White;
            BtnConsultar.Location = new Point(587, 112);
            BtnConsultar.Margin = new Padding(4, 5, 4, 5);
            BtnConsultar.Name = "BtnConsultar";
            BtnConsultar.Size = new Size(135, 44);
            BtnConsultar.TabIndex = 64;
            BtnConsultar.Text = "Consultar!!";
            BtnConsultar.UseVisualStyleBackColor = false;
            BtnConsultar.Click += BtnConsultarEquipo_Click;
            // 
            // BtnNewUser
            // 
            BtnNewUser.BackColor = Color.Navy;
            BtnNewUser.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnNewUser.ForeColor = Color.White;
            BtnNewUser.Location = new Point(21, 46);
            BtnNewUser.Margin = new Padding(4, 5, 4, 5);
            BtnNewUser.Name = "BtnNewUser";
            BtnNewUser.Size = new Size(162, 58);
            BtnNewUser.TabIndex = 56;
            BtnNewUser.Text = "Nuevo!!";
            BtnNewUser.UseVisualStyleBackColor = false;
            // 
            // TxtTipoEquipo
            // 
            TxtTipoEquipo.Font = new Font("Candara Light", 10F);
            TxtTipoEquipo.Location = new Point(274, 265);
            TxtTipoEquipo.Margin = new Padding(4, 5, 4, 5);
            TxtTipoEquipo.Name = "TxtTipoEquipo";
            TxtTipoEquipo.Size = new Size(265, 28);
            TxtTipoEquipo.TabIndex = 60;
            TxtTipoEquipo.TextChanged += TxtTipoEquipo_TextChanged;
            // 
            // BtnDelete
            // 
            BtnDelete.BackColor = Color.Navy;
            BtnDelete.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnDelete.ForeColor = Color.White;
            BtnDelete.Location = new Point(996, 398);
            BtnDelete.Margin = new Padding(4, 5, 4, 5);
            BtnDelete.Name = "BtnDelete";
            BtnDelete.Size = new Size(162, 58);
            BtnDelete.TabIndex = 66;
            BtnDelete.Text = "Inactivar!!";
            BtnDelete.UseVisualStyleBackColor = false;
            BtnDelete.Click += BtnDelete_Click;
            // 
            // BtnUpdate
            // 
            BtnUpdate.BackColor = Color.Navy;
            BtnUpdate.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnUpdate.ForeColor = Color.White;
            BtnUpdate.Location = new Point(796, 397);
            BtnUpdate.Margin = new Padding(4, 5, 4, 5);
            BtnUpdate.Name = "BtnUpdate";
            BtnUpdate.Size = new Size(162, 58);
            BtnUpdate.TabIndex = 65;
            BtnUpdate.Text = "Actualizar!!";
            BtnUpdate.UseVisualStyleBackColor = false;
            // 
            // TxtNameEquipo
            // 
            TxtNameEquipo.Font = new Font("Candara Light", 10F);
            TxtNameEquipo.Location = new Point(274, 118);
            TxtNameEquipo.Margin = new Padding(4, 5, 4, 5);
            TxtNameEquipo.Name = "TxtNameEquipo";
            TxtNameEquipo.Size = new Size(265, 28);
            TxtNameEquipo.TabIndex = 57;
            TxtNameEquipo.TextChanged += TxtNameEquipo_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(12, 121);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(73, 24);
            label4.TabIndex = 73;
            label4.Text = "Equipo:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(21, 265);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(51, 24);
            label2.TabIndex = 70;
            label2.Text = "Tipo:";
            // 
            // TxtCiudadEquipo
            // 
            TxtCiudadEquipo.Font = new Font("Candara Light", 10F);
            TxtCiudadEquipo.Location = new Point(274, 186);
            TxtCiudadEquipo.Margin = new Padding(4, 5, 4, 5);
            TxtCiudadEquipo.Name = "TxtCiudadEquipo";
            TxtCiudadEquipo.Size = new Size(265, 28);
            TxtCiudadEquipo.TabIndex = 59;
            TxtCiudadEquipo.TextChanged += TxtApellidos_TextChanged;
            // 
            // LblPassword
            // 
            LblPassword.AutoSize = true;
            LblPassword.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblPassword.ForeColor = Color.Navy;
            LblPassword.Location = new Point(13, 190);
            LblPassword.Margin = new Padding(4, 0, 4, 0);
            LblPassword.Name = "LblPassword";
            LblPassword.Size = new Size(73, 24);
            LblPassword.TabIndex = 69;
            LblPassword.Text = "Ciudad:";
            // 
            // LblUsuario
            // 
            LblUsuario.AutoSize = true;
            LblUsuario.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblUsuario.ForeColor = Color.Navy;
            LblUsuario.Location = new Point(12, 190);
            LblUsuario.Margin = new Padding(4, 0, 4, 0);
            LblUsuario.Name = "LblUsuario";
            LblUsuario.Size = new Size(0, 24);
            LblUsuario.TabIndex = 68;
            // 
            // BtnIngresar
            // 
            BtnIngresar.BackColor = Color.Navy;
            BtnIngresar.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnIngresar.ForeColor = Color.White;
            BtnIngresar.Location = new Point(599, 397);
            BtnIngresar.Margin = new Padding(4, 5, 4, 5);
            BtnIngresar.Name = "BtnIngresar";
            BtnIngresar.Size = new Size(162, 58);
            BtnIngresar.TabIndex = 63;
            BtnIngresar.Text = "Guardar!!";
            BtnIngresar.UseVisualStyleBackColor = false;
            BtnIngresar.Click += BtnIngresar_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Navy;
            button1.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(996, 511);
            button1.Margin = new Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new Size(162, 58);
            button1.TabIndex = 67;
            button1.Text = "Salir";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Equipos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1171, 614);
            Controls.Add(button2);
            Controls.Add(BtnConsultar);
            Controls.Add(BtnNewUser);
            Controls.Add(TxtTipoEquipo);
            Controls.Add(BtnDelete);
            Controls.Add(BtnUpdate);
            Controls.Add(TxtNameEquipo);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(TxtCiudadEquipo);
            Controls.Add(LblPassword);
            Controls.Add(LblUsuario);
            Controls.Add(BtnIngresar);
            Controls.Add(button1);
            Name = "Equipos";
            Text = "Equipos";
            Load += Equipos_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button BtnConsultar;
        private Button BtnNewUser;
        private TextBox TxtTipoEquipo;
        private Button BtnDelete;
        private Button BtnUpdate;
        private TextBox TxtNameEquipo;
        private Label label4;
        private Label label2;
        private TextBox TxtCiudadEquipo;
        private Label LblPassword;
        private Label LblUsuario;
        private Button BtnIngresar;
        private Button button1;
    }
}