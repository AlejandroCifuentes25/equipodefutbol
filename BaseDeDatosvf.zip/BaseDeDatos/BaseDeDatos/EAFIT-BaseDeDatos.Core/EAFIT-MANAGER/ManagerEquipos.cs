﻿using EAFIT_BaseDeDatos.Core.EAFIT_BROKER;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAFIT_BaseDeDatos.Core.EAFIT_MANAGER
{
    class ManagerEquipos
    {
        internal bool InsertarEquipo(Dictionary<string, string> ValuesEquipo)
        {
            BrokerEquipos InsertEquipo = new BrokerEquipos();
            return InsertEquipo.InsertarEquipo(ValuesEquipo);
        }

        internal bool ActualizarEquipo(Dictionary<string, string> ValuesEquipo)
        {
            BrokerEquipos UpdateEquipo = new BrokerEquipos();
            return UpdateEquipo.ActualizarEquipo(ValuesEquipo);
        }

        internal Dictionary<string, string> ValidarEquipo(string EquipoSearch)
        {
            BrokerEquipos ValidateEquipo = new BrokerEquipos();
            return ValidateEquipo.ValidarEquipo(EquipoSearch);
        }
    }
}