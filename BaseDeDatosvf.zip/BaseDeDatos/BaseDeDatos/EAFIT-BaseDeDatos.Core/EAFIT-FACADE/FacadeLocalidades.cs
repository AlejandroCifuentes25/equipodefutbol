﻿using EAFIT_BaseDeDatos.Core.EAFIT_BROKER;
using EAFIT_BaseDeDatos.Core.EAFIT_MANAGER;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAFIT_BaseDeDatos.Core.EAFIT_FACADE
{
    public class FacadeLocalidades
    {
        public bool InsertarLocalidad(Dictionary<string, string> ValuesLocalidad)
        {
            EAFIT_MANAGER.ManagerLocalidades insertLocalidad = new EAFIT_MANAGER.ManagerLocalidades();
            return insertLocalidad.InsertarLocalidad(ValuesLocalidad);
        }

        public bool ActualizarLocalidad(Dictionary<string, string> ValuesLocalidad)
        {
            EAFIT_MANAGER.ManagerLocalidades updateLocalidad = new EAFIT_MANAGER.ManagerLocalidades();
            return updateLocalidad.ActualizarLocalidad(ValuesLocalidad);
        }

        public Dictionary<string, string> ValidarLocalidad(string NombreLocalidad)
        {
            ManagerLocalidades validateLocalidad = new ManagerLocalidades();
            return validateLocalidad.ValidarLocalidad(NombreLocalidad);
        }
    }
}
