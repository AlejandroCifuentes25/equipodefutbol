﻿using EAFIT_BaseDeDatos.Core.EAFIT_BROKER;
using EAFIT_BaseDeDatos.Core.EAFIT_MANAGER;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAFIT_BaseDeDatos.Core.EAFIT_FACADE
{
    public class FacadeEquipos
    {
        public bool InsertarEquipo(Dictionary<string, string> ValuesEquipo)
        {
            EAFIT_MANAGER.ManagerEquipos InsertEquipo = new EAFIT_MANAGER.ManagerEquipos();
            return InsertEquipo.InsertarEquipo(ValuesEquipo);
        }

        public bool ActualizarEquipo(Dictionary<string, string> ValuesEquipo)
        {
            EAFIT_MANAGER.ManagerEquipos UpdateEquipo = new EAFIT_MANAGER.ManagerEquipos();
            return UpdateEquipo.ActualizarEquipo(ValuesEquipo);
        }

        public Dictionary<string, string> ValidarEquipo(string EquipoSearch)
        {
            ManagerEquipos ValidateEquipo = new ManagerEquipos();
            return ValidateEquipo.ValidarEquipo(EquipoSearch);
        }
    }
}
