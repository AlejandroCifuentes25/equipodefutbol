﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EAFIT_BaseDeDatos.Core.EAFIT_BROKER
{
    internal class BrokerEstadios
    {
        MySqlConnection Connection;
        BrokerConnection InsConnection = new BrokerConnection();

        internal bool InsertarEstadio(Dictionary<string, string> ValuesUsuario)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacLogeo = new MySqlCommand();
            transacLogeo.CommandText = string.Format("CALL  InsertarEstadio('{0}','{1}','{2}');", ValuesUsuario.GetValueOrDefault("nombre"),
                ValuesUsuario.GetValueOrDefault("ubicacion"), ValuesUsuario.GetValueOrDefault("capacidad_total"));
            transacLogeo.Connection = Connection;
            int ResultLogin = transacLogeo.ExecuteNonQuery();
            InsConnection.CloseConnection(Connection);
            if (ResultLogin > 0)
                return true;
            else
                return false;
        }
        internal Dictionary<string, string> ValidarEstadio(string nombreEstadio)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacLogeo = new MySqlCommand();
            transacLogeo.CommandText = string.Format("SELECT id_estadio, nombre, ubicacion, capacidad_total FROM Estadios WHERE nombre = '{0}'", nombreEstadio);
            transacLogeo.Connection = Connection;
            Dictionary<string, string> ReturnEstadio = new Dictionary<string, string>();
            MySqlDataReader Result = transacLogeo.ExecuteReader();
            while (Result.Read())
            {
                ReturnEstadio.Add("id_estadio", Result[0].ToString());
                ReturnEstadio.Add("nombre", Result[1].ToString());
                ReturnEstadio.Add("ubicacion", Result[2].ToString());
                ReturnEstadio.Add("capacidad_total", Result[3].ToString());
            }
            InsConnection.CloseConnection(Connection);
            return ReturnEstadio;
        }
        internal bool ActualizarEstadio(Dictionary<string, string> ValuesEstadio)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacUpdate = new MySqlCommand();
            transacUpdate.CommandText = string.Format("CALL ActualizarEstadio({0}, {1}, {2});",
             
                string.IsNullOrEmpty(ValuesEstadio.GetValueOrDefault("nombre")) ? "NULL" : string.Concat("'", ValuesEstadio.GetValueOrDefault("nombre"), "'"),
                string.IsNullOrEmpty(ValuesEstadio.GetValueOrDefault("ubicacion")) ? "NULL" : string.Concat("'", ValuesEstadio.GetValueOrDefault("ubicacion"), "'"),
                string.IsNullOrEmpty(ValuesEstadio.GetValueOrDefault("capacidad_total")) ? "NULL" : ValuesEstadio.GetValueOrDefault("capacidad_total"));
            transacUpdate.Connection = Connection;
            int Result = transacUpdate.ExecuteNonQuery();
            InsConnection.CloseConnection(Connection);
            if (Result > 0)
                return true;
            else
                return false;
        }

    }
}
