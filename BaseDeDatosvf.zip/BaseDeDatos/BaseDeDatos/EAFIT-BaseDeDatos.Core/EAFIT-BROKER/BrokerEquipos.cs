﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EAFIT_BaseDeDatos.Core.EAFIT_BROKER
{
    internal class BrokerEquipos
    {
        MySqlConnection Connection;
        BrokerConnection InsConnection = new BrokerConnection();

        internal bool InsertarEquipo(Dictionary<string, string> ValuesEquipo)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacLogeo = new MySqlCommand();
            transacLogeo.CommandText = string.Format("CALL InsertarEquipo('{0}','{1}','{2}');",
                ValuesEquipo.GetValueOrDefault("nombre"),
                ValuesEquipo.GetValueOrDefault("ciudad"),
                ValuesEquipo.GetValueOrDefault("tipo"));
            transacLogeo.Connection = Connection;
            int ResultLogin = transacLogeo.ExecuteNonQuery();
            InsConnection.CloseConnection(Connection);
            if (ResultLogin > 0)
                return true;
            else
                return false;
        }
        internal Dictionary<string, string> ValidarEquipo(string EquipoSearch)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacLogeo = new MySqlCommand();
            transacLogeo.CommandText = string.Format("SELECT id_equipo, nombre, ciudad, tipo FROM Equipos WHERE nombre = '{0}'", EquipoSearch);
            transacLogeo.Connection = Connection;
            Dictionary<string, string> ReturnEquipo = new Dictionary<string, string>();
            MySqlDataReader ResultLogin = transacLogeo.ExecuteReader();
            while (ResultLogin.Read())
            {
                ReturnEquipo.Add("id_equipo", ResultLogin[0].ToString());
                ReturnEquipo.Add("nombre", ResultLogin[1].ToString());
                ReturnEquipo.Add("ciudad", ResultLogin[2].ToString());
                ReturnEquipo.Add("tipo", ResultLogin[3].ToString());
            }
            InsConnection.CloseConnection(Connection);
            return ReturnEquipo;
        }
        internal bool ActualizarEquipo(Dictionary<string, string> ValuesEquipo)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacUpdate = new MySqlCommand();
            transacUpdate.CommandText = string.Format("CALL ActualizarEquipo({0}, {1}, {2});",
                string.IsNullOrEmpty(ValuesEquipo.GetValueOrDefault("nombre")) ? "NULL" : string.Concat("'", ValuesEquipo.GetValueOrDefault("nombre"), "'"),
                string.IsNullOrEmpty(ValuesEquipo.GetValueOrDefault("ciudad")) ? "NULL" : string.Concat("'", ValuesEquipo.GetValueOrDefault("ciudad"), "'"),
                string.IsNullOrEmpty(ValuesEquipo.GetValueOrDefault("tipo")) ? "NULL" : string.Concat("'", ValuesEquipo.GetValueOrDefault("tipo"), "'"));
            transacUpdate.Connection = Connection;
            int ResultLogin = transacUpdate.ExecuteNonQuery();
            InsConnection.CloseConnection(Connection);
            if (ResultLogin > 0)
                return true;
            else
                return false;
        }
    }
}
