﻿namespace EAFIT_BaseDeDatos.UI
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuPrincipal));
            LblTitulo = new Label();
            pictureBox1 = new PictureBox();
            BtnSalir = new Button();
            PBClientes = new PictureBox();
            PBProductos = new PictureBox();
            PBCategorias = new PictureBox();
            PBConfig = new PictureBox();
            LLClientes = new LinkLabel();
            LLProductos = new LinkLabel();
            LLCategorias = new LinkLabel();
            LLConfiguracion = new LinkLabel();
            linkLabel1 = new LinkLabel();
            Estadios = new LinkLabel();
            linkLabel3 = new LinkLabel();
            pictureEquipos = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBClientes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBProductos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBCategorias).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PBConfig).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureEquipos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // LblTitulo
            // 
            LblTitulo.AutoSize = true;
            LblTitulo.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblTitulo.ForeColor = Color.Navy;
            LblTitulo.Location = new Point(322, 25);
            LblTitulo.Name = "LblTitulo";
            LblTitulo.Size = new Size(220, 48);
            LblTitulo.TabIndex = 13;
            LblTitulo.Text = "Aplicación Base De Datos\r\n           Menú Principal ";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(10, 11);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(170, 82);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // BtnSalir
            // 
            BtnSalir.BackColor = Color.Navy;
            BtnSalir.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnSalir.ForeColor = Color.White;
            BtnSalir.Location = new Point(568, 347);
            BtnSalir.Margin = new Padding(3, 4, 3, 4);
            BtnSalir.Name = "BtnSalir";
            BtnSalir.Size = new Size(118, 48);
            BtnSalir.TabIndex = 11;
            BtnSalir.Text = "Salir";
            BtnSalir.UseVisualStyleBackColor = false;
            BtnSalir.Click += BtnSalir_Click;
            // 
            // PBClientes
            // 
            PBClientes.Image = Properties.Resources.Users;
            PBClientes.Location = new Point(45, 126);
            PBClientes.Margin = new Padding(2);
            PBClientes.Name = "PBClientes";
            PBClientes.Size = new Size(119, 110);
            PBClientes.SizeMode = PictureBoxSizeMode.StretchImage;
            PBClientes.TabIndex = 14;
            PBClientes.TabStop = false;
            PBClientes.Click += PBUsuarios_Click;
            // 
            // PBProductos
            // 
            PBProductos.Image = Properties.Resources.Products;
            PBProductos.Location = new Point(225, 124);
            PBProductos.Margin = new Padding(2);
            PBProductos.Name = "PBProductos";
            PBProductos.Size = new Size(119, 110);
            PBProductos.SizeMode = PictureBoxSizeMode.StretchImage;
            PBProductos.TabIndex = 15;
            PBProductos.TabStop = false;
            PBProductos.Click += PBProductos_Click;
            // 
            // PBCategorias
            // 
            PBCategorias.Image = Properties.Resources.categorias;
            PBCategorias.Location = new Point(378, 124);
            PBCategorias.Margin = new Padding(2);
            PBCategorias.Name = "PBCategorias";
            PBCategorias.Size = new Size(119, 110);
            PBCategorias.SizeMode = PictureBoxSizeMode.StretchImage;
            PBCategorias.TabIndex = 17;
            PBCategorias.TabStop = false;
            PBCategorias.Click += PBCategorias_Click;
            // 
            // PBConfig
            // 
            PBConfig.Image = Properties.Resources.Configuration;
            PBConfig.Location = new Point(530, 126);
            PBConfig.Margin = new Padding(2);
            PBConfig.Name = "PBConfig";
            PBConfig.Size = new Size(112, 110);
            PBConfig.SizeMode = PictureBoxSizeMode.StretchImage;
            PBConfig.TabIndex = 16;
            PBConfig.TabStop = false;
            PBConfig.Click += PBConfig_Click;
            // 
            // LLClientes
            // 
            LLClientes.AutoSize = true;
            LLClientes.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LLClientes.LinkBehavior = LinkBehavior.NeverUnderline;
            LLClientes.LinkColor = Color.Black;
            LLClientes.Location = new Point(19, 246);
            LLClientes.Margin = new Padding(2, 0, 2, 0);
            LLClientes.Name = "LLClientes";
            LLClientes.Size = new Size(164, 24);
            LLClientes.TabIndex = 18;
            LLClientes.TabStop = true;
            LLClientes.Text = "Clientes y Usuarios";
            LLClientes.Click += PBUsuarios_Click;
            // 
            // LLProductos
            // 
            LLProductos.AutoSize = true;
            LLProductos.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LLProductos.LinkBehavior = LinkBehavior.NeverUnderline;
            LLProductos.LinkColor = Color.Black;
            LLProductos.Location = new Point(240, 246);
            LLProductos.Margin = new Padding(2, 0, 2, 0);
            LLProductos.Name = "LLProductos";
            LLProductos.Size = new Size(95, 24);
            LLProductos.TabIndex = 19;
            LLProductos.TabStop = true;
            LLProductos.Text = "Productos";
            LLProductos.Click += PBProductos_Click;
            // 
            // LLCategorias
            // 
            LLCategorias.AutoSize = true;
            LLCategorias.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LLCategorias.LinkBehavior = LinkBehavior.NeverUnderline;
            LLCategorias.LinkColor = Color.Black;
            LLCategorias.Location = new Point(389, 246);
            LLCategorias.Margin = new Padding(2, 0, 2, 0);
            LLCategorias.Name = "LLCategorias";
            LLCategorias.Size = new Size(98, 24);
            LLCategorias.TabIndex = 20;
            LLCategorias.TabStop = true;
            LLCategorias.Text = "Categorias";
            LLCategorias.Click += PBCategorias_Click;
            // 
            // LLConfiguracion
            // 
            LLConfiguracion.AutoSize = true;
            LLConfiguracion.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LLConfiguracion.LinkBehavior = LinkBehavior.NeverUnderline;
            LLConfiguracion.LinkColor = Color.Black;
            LLConfiguracion.Location = new Point(530, 246);
            LLConfiguracion.Margin = new Padding(2, 0, 2, 0);
            LLConfiguracion.Name = "LLConfiguracion";
            LLConfiguracion.Size = new Size(126, 24);
            LLConfiguracion.TabIndex = 21;
            LLConfiguracion.TabStop = true;
            LLConfiguracion.Text = "Configuración";
            LLConfiguracion.LinkClicked += LLConfiguracion_LinkClicked;
            LLConfiguracion.Click += PBConfig_Click;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel1.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel1.LinkColor = Color.Black;
            linkLabel1.Location = new Point(727, 246);
            linkLabel1.Margin = new Padding(2, 0, 2, 0);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(76, 24);
            linkLabel1.TabIndex = 22;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Equipos";
            linkLabel1.LinkClicked += linkEquipos_LinkClicked;
            // 
            // Estadios
            // 
            Estadios.AutoSize = true;
            Estadios.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Estadios.LinkBehavior = LinkBehavior.NeverUnderline;
            Estadios.LinkColor = Color.Black;
            Estadios.Location = new Point(879, 246);
            Estadios.Margin = new Padding(2, 0, 2, 0);
            Estadios.Name = "Estadios";
            Estadios.Size = new Size(79, 24);
            Estadios.TabIndex = 23;
            Estadios.TabStop = true;
            Estadios.Text = "Estadios";
            Estadios.LinkClicked += linkLabel2_LinkClicked;
            // 
            // linkLabel3
            // 
            linkLabel3.AutoSize = true;
            linkLabel3.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            linkLabel3.LinkBehavior = LinkBehavior.NeverUnderline;
            linkLabel3.LinkColor = Color.Black;
            linkLabel3.Location = new Point(1014, 246);
            linkLabel3.Margin = new Padding(2, 0, 2, 0);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(108, 24);
            linkLabel3.TabIndex = 24;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "Localidades";
            // 
            // pictureEquipos
            // 
            pictureEquipos.Image = (Image)resources.GetObject("pictureEquipos.Image");
            pictureEquipos.Location = new Point(703, 126);
            pictureEquipos.Margin = new Padding(2);
            pictureEquipos.Name = "pictureEquipos";
            pictureEquipos.Size = new Size(112, 110);
            pictureEquipos.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureEquipos.TabIndex = 25;
            pictureEquipos.TabStop = false;
            pictureEquipos.Click += pictureEquipos_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(858, 126);
            pictureBox2.Margin = new Padding(2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(112, 110);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 26;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureEstadios_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(987, 112);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(169, 131);
            pictureBox3.TabIndex = 27;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureLocalidades_Click;
            // 
            // MenuPrincipal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1168, 600);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureEquipos);
            Controls.Add(linkLabel3);
            Controls.Add(Estadios);
            Controls.Add(linkLabel1);
            Controls.Add(LLConfiguracion);
            Controls.Add(LLCategorias);
            Controls.Add(LLProductos);
            Controls.Add(LLClientes);
            Controls.Add(PBCategorias);
            Controls.Add(PBConfig);
            Controls.Add(PBProductos);
            Controls.Add(PBClientes);
            Controls.Add(LblTitulo);
            Controls.Add(pictureBox1);
            Controls.Add(BtnSalir);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(2);
            Name = "MenuPrincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EAFIT - Menu Principal logeo";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBClientes).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBProductos).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBCategorias).EndInit();
            ((System.ComponentModel.ISupportInitialize)PBConfig).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureEquipos).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LblTitulo;
        private PictureBox pictureBox1;
        private Button BtnSalir;
        private PictureBox PBClientes;
        private PictureBox PBProductos;
        private PictureBox PBCategorias;
        private PictureBox PBConfig;
        private LinkLabel LLClientes;
        private LinkLabel LLProductos;
        private LinkLabel LLCategorias;
        private LinkLabel LLConfiguracion;
        private LinkLabel linkLabel1;
        private LinkLabel Estadios;
        private LinkLabel linkLabel3;
        private PictureBox pictureEquipos;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
    }
}