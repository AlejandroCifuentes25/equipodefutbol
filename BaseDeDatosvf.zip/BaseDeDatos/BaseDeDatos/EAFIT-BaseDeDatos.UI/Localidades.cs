﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EAFIT_BaseDeDatos.Core.EAFIT_FACADE;

namespace EAFIT_BaseDeDatos.UI
{

    public partial class Localidades : Form
    {
        bool Result = false;
        public Localidades(Form instanciaPpal)
        {
            InitializeComponent();
        }

        private void TxtIdEst_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            BtnIngresar.Enabled = false;
           

            FacadeLocalidades instSearch = new FacadeLocalidades();
            Dictionary<string, string> result = instSearch.ValidarLocalidad(TxtIdLoc.Text);

            if (result != null && result.Count > 0)
            {

                TxtIdLoc.Text = result.GetValueOrDefault("id_localidad");
                TxtIdEstadio.Text = result.GetValueOrDefault("id_estadio");
                TxtNameLoc.Text = result.GetValueOrDefault("nombre_localidad");
                TxtAforo.Text = result.GetValueOrDefault("aforo");
            }
            else
            {
                MessageBox.Show("No se encontró la localidad.");
            }

        }

        private void LblTitulo_Click(object sender, EventArgs e)
        {

        }

        private void BtnNewUser_Click(object sender, EventArgs e)
        {
            LimpiarFormulario();
        }
        private void LimpiarFormulario()
        {
            TxtIdLoc.Text = TxtNameLoc.Text = TxtAforo.Text = string.Empty;
          
            BtnIngresar.Enabled = true;
        }

        private void BtnIngresar_Click(object sender, EventArgs e)
        {
            ExecuteLocalidad2(1);
            if (Result)
            {
                MessageBox.Show("Ingreso exitoso!!", "Ingreso de localidad", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarFormulario();
            }
            else
            {
                MessageBox.Show("Falla al ingresar la localidad, validar los datos enviados", "Ingreso de localidad", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        internal bool ExecuteLocalidad2(int Accion)
        {
            Result = false;
            
            string idEstadio = (TxtIdEstadio.Text ?? "").Trim();
            string nombre = (TxtNameLoc.Text ?? "").Trim();
            string aforo = (TxtAforo.Text ?? "").Trim();

            bool aforoOk = int.TryParse(aforo, out _);
            bool idEstadioOk = int.TryParse(idEstadio, out _);

            if (string.IsNullOrWhiteSpace(nombre) ||
                string.IsNullOrWhiteSpace(idEstadio) ||
                string.IsNullOrWhiteSpace(aforo) ||
                !aforoOk || !idEstadioOk)
            {
                MessageBox.Show(
                    "Validar los datos ingresados.\n" +
                    "● Nombre, ID del estadio y aforo son obligatorios\n" +
                    "● ID del estadio y aforo deben ser numéricos",
                    "Error al ingresar los datos",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
                return Result;
            }

            var values = new Dictionary<string, string>
            {
                ["id_estadio"] = idEstadio,
                ["nombre_localidad"] = nombre,
                ["aforo"] = aforo
            };

            var facade = new FacadeLocalidades();

            if (Accion == 1)
                Result = facade.InsertarLocalidad(values);
            else if (Accion == 2)
                Result = facade.ActualizarLocalidad(values);

            return Result;
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Localidades_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
        internal bool ExecuteLocalidad(int Accion)
        {
            Result = false;

            string idLocalidad = (TxtIdLoc.Text ?? "").Trim();
            string idEstadio = (TxtIdEstadio.Text ?? "").Trim();
            string nombre = (TxtNameLoc.Text ?? "").Trim();
            string aforo = (TxtAforo.Text ?? "").Trim();

            bool idLocOk = int.TryParse(idLocalidad, out _);
            bool idEstOk = int.TryParse(idEstadio, out _);
            bool aforoOk = int.TryParse(aforo, out _);

            if (string.IsNullOrWhiteSpace(nombre) ||
                string.IsNullOrWhiteSpace(idEstadio) ||
                string.IsNullOrWhiteSpace(aforo) ||
                !idEstOk || !aforoOk ||
                (Accion == 2 && !idLocOk))
            {
                MessageBox.Show(
                    "Valida los datos:\n" +
                    "• Nombre, ID estadio y aforo son obligatorios\n" +
                    "• ID estadio y aforo deben ser numéricos\n" +
                    "• Para ACTUALIZAR, debes indicar ID localidad numérico",
                    "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error
                );
                return Result;
            }

            var values = new Dictionary<string, string>
            {
                ["id_estadio"] = idEstadio,
                ["nombre_localidad"] = nombre,
                ["aforo"] = aforo
            };
            if (Accion == 2)
                values["id_localidad"] = idLocalidad; // <-- IMPRESCINDIBLE

            var facade = new FacadeLocalidades();
            if (Accion == 1)
                Result = facade.InsertarLocalidad(values);
            else if (Accion == 2)
                Result = facade.ActualizarLocalidad(values);

            return Result;
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            ExecuteLocalidad(2);
            if (Result)
            {
                MessageBox.Show("Actualización exitosa!!", "Actualización de localidad", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarFormulario();
            }
            else
                MessageBox.Show("Falla al actualizar el localidad, validar los datos enviados", "Actualización de localidad", MessageBoxButtons.OK, MessageBoxIcon.Error);


        }
    }
    }

