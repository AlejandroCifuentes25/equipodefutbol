﻿namespace EAFIT_BaseDeDatos.UI
{
    partial class Localidades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            BtnConsultar = new Button();
            BtnNewUser = new Button();
            BtnUpdate = new Button();
            TxtIdLoc = new TextBox();
            NombreLoc = new Label();
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            LblTitulo = new Label();
            TxtAforo = new TextBox();
            TxtNameLoc = new TextBox();
            LblPassword = new Label();
            LblUsuario = new Label();
            BtnIngresar = new Button();
            BtnSalir = new Button();
            LLConfiguracion = new LinkLabel();
            label4 = new Label();
            TxtIdEstadio = new TextBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Navy;
            button1.Font = new Font("Candara", 9F);
            button1.ForeColor = Color.White;
            button1.Location = new Point(815, 48);
            button1.Margin = new Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new Size(135, 44);
            button1.TabIndex = 75;
            button1.Text = " Menú";
            button1.UseVisualStyleBackColor = false;
            // 
            // BtnConsultar
            // 
            BtnConsultar.BackColor = Color.Navy;
            BtnConsultar.Font = new Font("Candara", 9F);
            BtnConsultar.ForeColor = Color.White;
            BtnConsultar.Location = new Point(468, 176);
            BtnConsultar.Margin = new Padding(4, 5, 4, 5);
            BtnConsultar.Name = "BtnConsultar";
            BtnConsultar.Size = new Size(135, 44);
            BtnConsultar.TabIndex = 64;
            BtnConsultar.Text = "Consultar!!";
            BtnConsultar.UseVisualStyleBackColor = false;
            BtnConsultar.Click += BtnConsultar_Click;
            // 
            // BtnNewUser
            // 
            BtnNewUser.BackColor = Color.Navy;
            BtnNewUser.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnNewUser.ForeColor = Color.White;
            BtnNewUser.Location = new Point(-5, 72);
            BtnNewUser.Margin = new Padding(4, 5, 4, 5);
            BtnNewUser.Name = "BtnNewUser";
            BtnNewUser.Size = new Size(162, 58);
            BtnNewUser.TabIndex = 59;
            BtnNewUser.Text = "Nuevo!!";
            BtnNewUser.UseVisualStyleBackColor = false;
            BtnNewUser.Click += BtnNewUser_Click;
            // 
            // BtnUpdate
            // 
            BtnUpdate.BackColor = Color.Navy;
            BtnUpdate.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnUpdate.ForeColor = Color.White;
            BtnUpdate.Location = new Point(779, 461);
            BtnUpdate.Margin = new Padding(4, 5, 4, 5);
            BtnUpdate.Name = "BtnUpdate";
            BtnUpdate.Size = new Size(162, 58);
            BtnUpdate.TabIndex = 65;
            BtnUpdate.Text = "Actualizar!!";
            BtnUpdate.UseVisualStyleBackColor = false;
            BtnUpdate.Click += BtnUpdate_Click;
            // 
            // TxtIdLoc
            // 
            TxtIdLoc.Font = new Font("Candara Light", 10F);
            TxtIdLoc.Location = new Point(174, 184);
            TxtIdLoc.Margin = new Padding(4, 5, 4, 5);
            TxtIdLoc.Name = "TxtIdLoc";
            TxtIdLoc.Size = new Size(265, 28);
            TxtIdLoc.TabIndex = 60;
            TxtIdLoc.TextChanged += TxtIdEst_TextChanged;
            // 
            // NombreLoc
            // 
            NombreLoc.AutoSize = true;
            NombreLoc.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            NombreLoc.ForeColor = Color.Navy;
            NombreLoc.Location = new Point(40, 186);
            NombreLoc.Margin = new Padding(4, 0, 4, 0);
            NombreLoc.Name = "NombreLoc";
            NombreLoc.Size = new Size(117, 24);
            NombreLoc.TabIndex = 74;
            NombreLoc.Text = "Id Localidad:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(-5, 560);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(0, 24);
            label3.TabIndex = 73;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(-5, 477);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(0, 24);
            label1.TabIndex = 72;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(-5, 397);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(0, 24);
            label2.TabIndex = 71;
            // 
            // LblTitulo
            // 
            LblTitulo.AutoSize = true;
            LblTitulo.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblTitulo.ForeColor = Color.Navy;
            LblTitulo.Location = new Point(384, 9);
            LblTitulo.Margin = new Padding(4, 0, 4, 0);
            LblTitulo.Name = "LblTitulo";
            LblTitulo.Size = new Size(258, 24);
            LblTitulo.TabIndex = 70;
            LblTitulo.Text = "Administración de localidades";
            LblTitulo.Click += LblTitulo_Click;
            // 
            // TxtAforo
            // 
            TxtAforo.Font = new Font("Candara Light", 10F);
            TxtAforo.Location = new Point(276, 450);
            TxtAforo.Margin = new Padding(4, 5, 4, 5);
            TxtAforo.Name = "TxtAforo";
            TxtAforo.Size = new Size(265, 28);
            TxtAforo.TabIndex = 62;
            // 
            // TxtNameLoc
            // 
            TxtNameLoc.Font = new Font("Candara Light", 10F);
            TxtNameLoc.Location = new Point(276, 393);
            TxtNameLoc.Margin = new Padding(4, 5, 4, 5);
            TxtNameLoc.Name = "TxtNameLoc";
            TxtNameLoc.Size = new Size(265, 28);
            TxtNameLoc.TabIndex = 61;
            // 
            // LblPassword
            // 
            LblPassword.AutoSize = true;
            LblPassword.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblPassword.ForeColor = Color.Navy;
            LblPassword.Location = new Point(86, 450);
            LblPassword.Margin = new Padding(4, 0, 4, 0);
            LblPassword.Name = "LblPassword";
            LblPassword.Size = new Size(63, 24);
            LblPassword.TabIndex = 69;
            LblPassword.Text = "Aforo:";
            // 
            // LblUsuario
            // 
            LblUsuario.AutoSize = true;
            LblUsuario.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblUsuario.ForeColor = Color.Navy;
            LblUsuario.Location = new Point(32, 392);
            LblUsuario.Margin = new Padding(4, 0, 4, 0);
            LblUsuario.Name = "LblUsuario";
            LblUsuario.Size = new Size(207, 24);
            LblUsuario.TabIndex = 68;
            LblUsuario.Text = "Nombre de la localidad:";
            // 
            // BtnIngresar
            // 
            BtnIngresar.BackColor = Color.Navy;
            BtnIngresar.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnIngresar.ForeColor = Color.White;
            BtnIngresar.Location = new Point(582, 461);
            BtnIngresar.Margin = new Padding(4, 5, 4, 5);
            BtnIngresar.Name = "BtnIngresar";
            BtnIngresar.Size = new Size(162, 58);
            BtnIngresar.TabIndex = 63;
            BtnIngresar.Text = "Guardar!!";
            BtnIngresar.UseVisualStyleBackColor = false;
            BtnIngresar.Click += BtnIngresar_Click;
            // 
            // BtnSalir
            // 
            BtnSalir.BackColor = Color.Navy;
            BtnSalir.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnSalir.ForeColor = Color.White;
            BtnSalir.Location = new Point(979, 575);
            BtnSalir.Margin = new Padding(4, 5, 4, 5);
            BtnSalir.Name = "BtnSalir";
            BtnSalir.Size = new Size(162, 58);
            BtnSalir.TabIndex = 67;
            BtnSalir.Text = "Salir";
            BtnSalir.UseVisualStyleBackColor = false;
            // 
            // LLConfiguracion
            // 
            LLConfiguracion.AutoSize = true;
            LLConfiguracion.Font = new Font("Candara Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LLConfiguracion.LinkBehavior = LinkBehavior.NeverUnderline;
            LLConfiguracion.LinkColor = Color.Black;
            LLConfiguracion.Location = new Point(1106, 298);
            LLConfiguracion.Margin = new Padding(2, 0, 2, 0);
            LLConfiguracion.Name = "LLConfiguracion";
            LLConfiguracion.Size = new Size(0, 24);
            LLConfiguracion.TabIndex = 58;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(79, 335);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(97, 24);
            label4.TabIndex = 76;
            label4.Text = "Id Estadio:";
            label4.Click += label4_Click;
            // 
            // TxtIdEstadio
            // 
            TxtIdEstadio.Font = new Font("Candara Light", 10F);
            TxtIdEstadio.Location = new Point(276, 335);
            TxtIdEstadio.Margin = new Padding(4, 5, 4, 5);
            TxtIdEstadio.Name = "TxtIdEstadio";
            TxtIdEstadio.Size = new Size(265, 28);
            TxtIdEstadio.TabIndex = 77;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(126, 135);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(441, 28);
            label5.TabIndex = 78;
            label5.Text = "Id localidad solo para consultar o actualizar:";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Navy;
            label6.Location = new Point(139, 264);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(0, 20);
            label6.TabIndex = 79;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Candara", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Navy;
            label7.Location = new Point(163, 264);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(247, 28);
            label7.TabIndex = 80;
            label7.Text = "Informacion de estadio:";
            label7.Click += label7_Click;
            // 
            // Localidades
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1136, 629);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(TxtIdEstadio);
            Controls.Add(label4);
            Controls.Add(button1);
            Controls.Add(BtnConsultar);
            Controls.Add(BtnNewUser);
            Controls.Add(BtnUpdate);
            Controls.Add(TxtIdLoc);
            Controls.Add(NombreLoc);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(LblTitulo);
            Controls.Add(TxtAforo);
            Controls.Add(TxtNameLoc);
            Controls.Add(LblPassword);
            Controls.Add(LblUsuario);
            Controls.Add(BtnIngresar);
            Controls.Add(BtnSalir);
            Controls.Add(LLConfiguracion);
            Name = "Localidades";
            Text = "Localidades";
            Load += Localidades_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button BtnConsultar;
        private Button BtnNewUser;
        private Button BtnUpdate;
        private TextBox TxtIdLoc;
        private Label NombreLoc;
        private Label label3;
        private Label label1;
        private Label label2;
        private Label LblTitulo;
        private TextBox TxtAforo;
        private TextBox TxtNameLoc;
        private Label LblPassword;
        private Label LblUsuario;
        private Button BtnIngresar;
        private Button BtnSalir;
        private LinkLabel LLConfiguracion;
        private Label label4;
        private TextBox TxtIdEstadio;
        private Label label5;
        private Label label6;
        private Label label7;
    }
}