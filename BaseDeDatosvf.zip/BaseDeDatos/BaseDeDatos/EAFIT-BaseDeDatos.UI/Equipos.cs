﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EAFIT_BaseDeDatos.Core.EAFIT_FACADE;

namespace EAFIT_BaseDeDatos.UI
{
    public partial class Equipos : Form
    {
        bool Result = false;
        public Equipos(Form instanciaPpal)
        {
            InitializeComponent();
        }

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            BtnIngresar.Enabled = false;


            FacadeEquipos instSearch = new FacadeEquipos();
            Dictionary<string, string> result = instSearch.ValidarEquipo(TxtNameEquipos.Text);

            if (result != null && result.Count > 0)
            {
                TxtNameEquipos.Text = result.GetValueOrDefault("nombre");
                TxtCiudadEquipo.Text = result.GetValueOrDefault("ciudad");
                TxtTipo.Text = result.GetValueOrDefault("tipo");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void BtnNewUser_Click(object sender, EventArgs e)
        {
            LimpiarFormulario();
        }
        private void LimpiarFormulario()
        {
            TxtNameEquipos.Text = TxtCiudadEquipo.Text = TxtTipo.Text = string.Empty;

            BtnIngresar.Enabled = true;
        }

        private void BtnIngresar_Click(object sender, EventArgs e)
        {
            ExecuteEquipos(1);
            if (Result)
            {
                MessageBox.Show("Ingreso exitoso!!", "Ingreso de equipo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarFormulario();
            }
            else
            {
                MessageBox.Show("Falla al ingresar el equipo, validar los datos enviados", "Ingreso de equipo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        internal bool ExecuteEquipos(int Accion)
        {
            Result = false;

            string nombre = (TxtNameEquipos.Text ?? "").Trim();
            string ciudad = (TxtCiudadEquipo.Text ?? "").Trim();
            string tipo = (TxtTipo.Text ?? "").Trim();

            if (string.IsNullOrWhiteSpace(nombre) ||
                string.IsNullOrWhiteSpace(ciudad) ||
                string.IsNullOrWhiteSpace(tipo))
            {
                MessageBox.Show(
                    "Validar los datos ingresados.\n" +
                    "● Nombre, ciudad y tipo son obligatorios",
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
                return Result;
            }

            var values = new Dictionary<string, string>
            {
                ["nombre"] = nombre,
                ["ciudad"] = ciudad,
                ["tipo"] = tipo
            };

            var facade = new FacadeEquipos();
            if (Accion == 1)
                Result = facade.InsertarEquipo(values);
            else if (Accion == 2)
                Result = facade.ActualizarEquipo(values);

            return Result;
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            ExecuteEquipos(2);
            if (Result)
            {
                MessageBox.Show("Actualización exitosa!!", "Actualización de equipo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarFormulario();
            }
            else
                MessageBox.Show("Falla al actualizar el equipo, validar los datos enviados", "Actualización de equipo", MessageBoxButtons.OK, MessageBoxIcon.Error);


        }
    }
    }



