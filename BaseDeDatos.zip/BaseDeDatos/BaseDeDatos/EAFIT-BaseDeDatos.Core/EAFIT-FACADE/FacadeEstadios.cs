﻿using EAFIT_BaseDeDatos.Core.EAFIT_BROKER;
using EAFIT_BaseDeDatos.Core.EAFIT_MANAGER;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAFIT_BaseDeDatos.Core.EAFIT_FACADE
{
    public class FacadeEstadios
    {
        public bool InsertarEstadio(Dictionary<string, string> ValuesEstadio)
        {
            EAFIT_MANAGER.ManagerEstadios InsertEstadio = new EAFIT_MANAGER.ManagerEstadios();
            return InsertEstadio.InsertarEstadio(ValuesEstadio);
        }

        public bool ActualizarEstadio(Dictionary<string, string> ValuesEstadio)
        {
            EAFIT_MANAGER.ManagerEstadios UpdateEstadio = new EAFIT_MANAGER.ManagerEstadios();
            return UpdateEstadio.ActualizarEstadio(ValuesEstadio);
        }

        public Dictionary<string, string> ValidarEstadio(string NombreEstadio)
        {
            ManagerEstadios ValidateEstadio = new ManagerEstadios();
            return ValidateEstadio.ValidarEstadio(NombreEstadio);
        }
    }
}
