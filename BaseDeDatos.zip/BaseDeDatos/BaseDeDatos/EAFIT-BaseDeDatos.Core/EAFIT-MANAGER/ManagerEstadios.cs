﻿using EAFIT_BaseDeDatos.Core.EAFIT_BROKER;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAFIT_BaseDeDatos.Core.EAFIT_MANAGER
{
    class ManagerEstadios
    {
        internal bool InsertarEstadio(Dictionary<string, string> ValuesEstadio)
        {
            BrokerEstadios InsertEstadio = new BrokerEstadios();
            return InsertEstadio.InsertarEstadio(ValuesEstadio);
        }

        internal bool ActualizarEstadio(Dictionary<string, string> ValuesEstadio)
        {
            BrokerEstadios UpdateEstadio = new BrokerEstadios();
            return UpdateEstadio.ActualizarEstadio(ValuesEstadio);
        }

        internal Dictionary<string, string> ValidarEstadio(string NombreEstadio)
        {
            BrokerEstadios ValidateEstadio = new BrokerEstadios();
            return ValidateEstadio.ValidarEstadio(NombreEstadio);
        }
    }
}
