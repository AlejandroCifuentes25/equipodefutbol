﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EAFIT_BaseDeDatos.Core.EAFIT_BROKER
{
    internal class BrokerLocalidades
    {
        MySqlConnection Connection;
        BrokerConnection InsConnection = new BrokerConnection();

        internal bool InsertarLocalidad(Dictionary<string, string> ValuesLocalidad)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacInsert = new MySqlCommand();
            transacInsert.CommandText = string.Format("CALL InsertarLocalidad({0}, {1}, {2});",
                string.IsNullOrEmpty(ValuesLocalidad.GetValueOrDefault("id_estadio")) ? "NULL" : ValuesLocalidad.GetValueOrDefault("id_estadio"),
                string.IsNullOrEmpty(ValuesLocalidad.GetValueOrDefault("nombre_localidad")) ? "NULL" : "'" + ValuesLocalidad.GetValueOrDefault("nombre_localidad").Replace("'", "''") + "'",
                string.IsNullOrEmpty(ValuesLocalidad.GetValueOrDefault("aforo")) ? "NULL" : ValuesLocalidad.GetValueOrDefault("aforo"));
            transacInsert.Connection = Connection;
            int Result = transacInsert.ExecuteNonQuery();
            InsConnection.CloseConnection(Connection);
            if (Result > 0)
                return true;
            else
                return false;
        }

        internal Dictionary<string, string> ValidarLocalidad(string nombreLocalidad)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transac = new MySqlCommand();
            transac.CommandText = string.Format("SELECT id_localidad, id_estadio, nombre_localidad, aforo FROM Localidades WHERE nombre_localidad = '{0}'", nombreLocalidad);
            transac.Connection = Connection;
            Dictionary<string, string> ReturnLocalidad = new Dictionary<string, string>();
            MySqlDataReader Result = transac.ExecuteReader();
            while (Result.Read())
            {
                ReturnLocalidad.Add("id_localidad", Result[0].ToString());
                ReturnLocalidad.Add("id_estadio", Result[1].ToString());
                ReturnLocalidad.Add("nombre_localidad", Result[2].ToString());
                ReturnLocalidad.Add("aforo", Result[3].ToString());
            }
            InsConnection.CloseConnection(Connection);
            return ReturnLocalidad;
        }

        internal bool ActualizarLocalidad(Dictionary<string, string> ValuesLocalidad)
        {
            Connection = InsConnection.OpenConnection();
            MySqlCommand transacUpdate = new MySqlCommand();
            transacUpdate.CommandText = string.Format("CALL ActualizarLocalidad({0}, {1}, {2}, {3});",
                string.IsNullOrEmpty(ValuesLocalidad.GetValueOrDefault("id_localidad")) ? "NULL" : ValuesLocalidad.GetValueOrDefault("id_localidad"),
                string.IsNullOrEmpty(ValuesLocalidad.GetValueOrDefault("id_estadio")) ? "NULL" : ValuesLocalidad.GetValueOrDefault("id_estadio"),
                string.IsNullOrEmpty(ValuesLocalidad.GetValueOrDefault("nombre_localidad")) ? "NULL" : "'" + ValuesLocalidad.GetValueOrDefault("nombre_localidad").Replace("'", "''") + "'",
                string.IsNullOrEmpty(ValuesLocalidad.GetValueOrDefault("aforo")) ? "NULL" : ValuesLocalidad.GetValueOrDefault("aforo"));
            transacUpdate.Connection = Connection;
            int Result = transacUpdate.ExecuteNonQuery();
            InsConnection.CloseConnection(Connection);
            if (Result > 0)
                return true;
            else
                return false;
        }
    }
}
