﻿namespace EAFIT_BaseDeDatos.UI
{
    partial class Productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnNewUser = new Button();
            CBState = new ComboBox();
            TxtEmail = new TextBox();
            BtnDelete = new Button();
            BtnUpdate = new Button();
            CBClientType = new ComboBox();
            TxtNameUser = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            TxtApellidos = new TextBox();
            TxtUsuario = new TextBox();
            LblPassword = new Label();
            LblUsuario = new Label();
            BtnIngresar = new Button();
            button1 = new Button();
            BtnConsultar = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // BtnNewUser
            // 
            BtnNewUser.BackColor = Color.Navy;
            BtnNewUser.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnNewUser.ForeColor = Color.White;
            BtnNewUser.Location = new Point(13, 5);
            BtnNewUser.Margin = new Padding(4, 5, 4, 5);
            BtnNewUser.Name = "BtnNewUser";
            BtnNewUser.Size = new Size(162, 58);
            BtnNewUser.TabIndex = 33;
            BtnNewUser.Text = "Nuevo!!";
            BtnNewUser.UseVisualStyleBackColor = false;
            BtnNewUser.Click += BtnNewUser_Click;
            // 
            // CBState
            // 
            CBState.Font = new Font("Candara Light", 10F);
            CBState.FormattingEnabled = true;
            CBState.Items.AddRange(new object[] { "--Seleccionar--", "   Activo", "   Inactivo" });
            CBState.Location = new Point(266, 456);
            CBState.Name = "CBState";
            CBState.Size = new Size(265, 29);
            CBState.TabIndex = 39;
            // 
            // TxtEmail
            // 
            TxtEmail.Font = new Font("Candara Light", 10F);
            TxtEmail.Location = new Point(266, 293);
            TxtEmail.Margin = new Padding(4, 5, 4, 5);
            TxtEmail.Name = "TxtEmail";
            TxtEmail.Size = new Size(265, 28);
            TxtEmail.TabIndex = 37;
            // 
            // BtnDelete
            // 
            BtnDelete.BackColor = Color.Navy;
            BtnDelete.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnDelete.ForeColor = Color.White;
            BtnDelete.Location = new Point(988, 357);
            BtnDelete.Margin = new Padding(4, 5, 4, 5);
            BtnDelete.Name = "BtnDelete";
            BtnDelete.Size = new Size(162, 58);
            BtnDelete.TabIndex = 45;
            BtnDelete.Text = "Inactivar!!";
            BtnDelete.UseVisualStyleBackColor = false;
            // 
            // BtnUpdate
            // 
            BtnUpdate.BackColor = Color.Navy;
            BtnUpdate.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnUpdate.ForeColor = Color.White;
            BtnUpdate.Location = new Point(788, 356);
            BtnUpdate.Margin = new Padding(4, 5, 4, 5);
            BtnUpdate.Name = "BtnUpdate";
            BtnUpdate.Size = new Size(162, 58);
            BtnUpdate.TabIndex = 44;
            BtnUpdate.Text = "Actualizar!!";
            BtnUpdate.UseVisualStyleBackColor = false;
            BtnUpdate.Click += BtnUpdate_Click;
            // 
            // CBClientType
            // 
            CBClientType.Font = new Font("Candara Light", 10F);
            CBClientType.FormattingEnabled = true;
            CBClientType.Items.AddRange(new object[] { "--Seleccionar--", "   Cliente", "   Usuario", "   Otro..." });
            CBClientType.Location = new Point(266, 372);
            CBClientType.Name = "CBClientType";
            CBClientType.Size = new Size(265, 29);
            CBClientType.TabIndex = 38;
            // 
            // TxtNameUser
            // 
            TxtNameUser.Font = new Font("Candara Light", 10F);
            TxtNameUser.Location = new Point(266, 77);
            TxtNameUser.Margin = new Padding(4, 5, 4, 5);
            TxtNameUser.Name = "TxtNameUser";
            TxtNameUser.Size = new Size(265, 28);
            TxtNameUser.TabIndex = 34;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(4, 80);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(193, 24);
            label4.TabIndex = 52;
            label4.Text = "Usuario de aplicación:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(4, 455);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(72, 24);
            label3.TabIndex = 51;
            label3.Text = "Estado:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(4, 372);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(151, 24);
            label1.TabIndex = 50;
            label1.Text = "Cliente / Usuario:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(4, 292);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(141, 24);
            label2.TabIndex = 49;
            label2.Text = "Correo Usuario:";
            // 
            // TxtApellidos
            // 
            TxtApellidos.Font = new Font("Candara Light", 10F);
            TxtApellidos.Location = new Point(266, 216);
            TxtApellidos.Margin = new Padding(4, 5, 4, 5);
            TxtApellidos.Name = "TxtApellidos";
            TxtApellidos.Size = new Size(265, 28);
            TxtApellidos.TabIndex = 36;
            // 
            // TxtUsuario
            // 
            TxtUsuario.Font = new Font("Candara Light", 10F);
            TxtUsuario.Location = new Point(266, 147);
            TxtUsuario.Margin = new Padding(4, 5, 4, 5);
            TxtUsuario.Name = "TxtUsuario";
            TxtUsuario.Size = new Size(265, 28);
            TxtUsuario.TabIndex = 35;
            // 
            // LblPassword
            // 
            LblPassword.AutoSize = true;
            LblPassword.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblPassword.ForeColor = Color.Navy;
            LblPassword.Location = new Point(4, 224);
            LblPassword.Margin = new Padding(4, 0, 4, 0);
            LblPassword.Name = "LblPassword";
            LblPassword.Size = new Size(161, 24);
            LblPassword.TabIndex = 48;
            LblPassword.Text = "Apellidos Usuario:";
            // 
            // LblUsuario
            // 
            LblUsuario.AutoSize = true;
            LblUsuario.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LblUsuario.ForeColor = Color.Navy;
            LblUsuario.Location = new Point(4, 149);
            LblUsuario.Margin = new Padding(4, 0, 4, 0);
            LblUsuario.Name = "LblUsuario";
            LblUsuario.Size = new Size(152, 24);
            LblUsuario.TabIndex = 47;
            LblUsuario.Text = "Nombre Usuario:";
            // 
            // BtnIngresar
            // 
            BtnIngresar.BackColor = Color.Navy;
            BtnIngresar.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnIngresar.ForeColor = Color.White;
            BtnIngresar.Location = new Point(591, 356);
            BtnIngresar.Margin = new Padding(4, 5, 4, 5);
            BtnIngresar.Name = "BtnIngresar";
            BtnIngresar.Size = new Size(162, 58);
            BtnIngresar.TabIndex = 42;
            BtnIngresar.Text = "Guardar!!";
            BtnIngresar.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.Navy;
            button1.Font = new Font("Candara", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(988, 470);
            button1.Margin = new Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new Size(162, 58);
            button1.TabIndex = 46;
            button1.Text = "Salir";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // BtnConsultar
            // 
            BtnConsultar.BackColor = Color.Navy;
            BtnConsultar.Font = new Font("Candara", 9F);
            BtnConsultar.ForeColor = Color.White;
            BtnConsultar.Location = new Point(579, 71);
            BtnConsultar.Margin = new Padding(4, 5, 4, 5);
            BtnConsultar.Name = "BtnConsultar";
            BtnConsultar.Size = new Size(135, 44);
            BtnConsultar.TabIndex = 43;
            BtnConsultar.Text = "Consultar!!";
            BtnConsultar.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Navy;
            button2.Font = new Font("Candara", 9F);
            button2.ForeColor = Color.White;
            button2.Location = new Point(868, 61);
            button2.Margin = new Padding(4, 5, 4, 5);
            button2.Name = "button2";
            button2.Size = new Size(135, 44);
            button2.TabIndex = 55;
            button2.Text = " menú";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // Productos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1155, 574);
            Controls.Add(button2);
            Controls.Add(BtnConsultar);
            Controls.Add(BtnNewUser);
            Controls.Add(CBState);
            Controls.Add(TxtEmail);
            Controls.Add(BtnDelete);
            Controls.Add(BtnUpdate);
            Controls.Add(CBClientType);
            Controls.Add(TxtNameUser);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(TxtApellidos);
            Controls.Add(TxtUsuario);
            Controls.Add(LblPassword);
            Controls.Add(LblUsuario);
            Controls.Add(BtnIngresar);
            Controls.Add(button1);
            Margin = new Padding(2);
            Name = "Productos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = " Estadios";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button BtnNewUser;
        private ComboBox CBState;
        private TextBox TxtEmail;
        private Button BtnDelete;
        private Button BtnUpdate;
        private ComboBox CBClientType;
        private TextBox TxtNameUser;
        private Label label4;
        private Label label3;
        private Label label1;
        private Label label2;
        private TextBox TxtApellidos;
        private TextBox TxtUsuario;
        private Label LblPassword;
        private Label LblUsuario;
        private Button BtnIngresar;
        private Button button1;
        private Button BtnConsultar;
        private Button button2;
    }
}