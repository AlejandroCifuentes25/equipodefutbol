﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EAFIT_BaseDeDatos.UI
{
    public partial class Productos : Form
    {
        Form InstanciaPpal;
        public Productos(Form ppal)
        {
            InitializeComponent();
            InstanciaPpal = ppal;
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            InstanciaPpal.Close();
        }

        private void BtnNewUser_Click(object sender, EventArgs e)
        {

        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void BtnMenu_Click(object sender, EventArgs e)
        {
            MenuPrincipal NuevoMenu = new MenuPrincipal(this);
            NuevoMenu.Show();
            this.Hide();
        }
    }
}
